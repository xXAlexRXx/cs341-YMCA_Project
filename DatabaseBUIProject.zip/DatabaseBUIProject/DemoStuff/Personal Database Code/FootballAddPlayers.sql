#Arizona Cardinals Players

insert into Player (PlayerName, Birthdate, Position)
	values 
    ('Kyler Murray', '1997-08-07', 'QB'),
	('James Connor', '1995-05-05', 'RB'),
    ('Trey Benson', '2003-07-21', 'RB'),
    ('Greg Dortch', '1998-05-29', 'WR'),
	('Michael Wilson', '2000-02-23', 'WR'),
	('Marvin Harrison Jr.', '2002-08-11', 'WR'),
    ('Trey McBride', '1999-11-22', 'TE'),
	('Zay Jones', '1995-03-30', 'WR');
    
#Atlanta Falcons Players
insert into Player (PlayerName, Birthdate, Position)
	values 
    ('Kirk Cousins', '1988-08-19', 'QB'),
	('Bijan Robinson', '2002-01-30', 'RB'),
    ('Tyler Allgeier', '2000-04-15', 'RB'),
    ('Drake London', '2001-07-24', 'WR'),
	('Darnell Mooney', '1997-10-29', 'WR'),
	('Ray-Ray McCloud', '1996-10-15', 'WR'),
    ('Kyle Pitts', '2000-10-06', 'TE'),
	('KhaDarel Hodge', '1995-01-03', 'WR');

#Baltimore Ravens Players
INSERT INTO Player (PlayerName, Birthdate, Position)
VALUES 
    ('Lamar Jackson', '1997-01-07', 'QB'),
    ('Derrick Henry', '1994-01-04', 'RB'),
    ('Justice Hill', '1998-04-15', 'RB'),
    ('Zay Flowers', '1999-07-30', 'WR'),
    ('Rashod Bateman', '1999-10-02', 'WR'),
    ('Nelson Agholor', '1993-05-24', 'WR'),
    ('Isaiah Likely', '1999-11-16', 'TE'),
    ('Mark Andrews', '1995-09-06', 'TE');
    
#Buffalo Bills Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('Josh Allen', '1996-05-21', 'QB'),
    ('James Cook', '1999-9-25', 'RB'),
    ('Ray Davis', '1999-11-11', 'RB'),
    ('Curtis Samuel', '1996-08-11', 'WR'),
    ('Khalil Shakir', '2000-02-03', 'WR'),
    ('Keon Coleman', '2003-05-17', 'WR'),
    ('Dalton Kincaid', '1999-10-18', 'TE'),
    ('Dawson Knox', '1996-11-14', 'TE');
    
#Carolina Panthers Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('Andy Dalton', '1987-10-29', 'QB'),
    ('Bryce Young', '2001-07-25', 'QB'),
    ('Chubba Hubbard', '1999-07-11', 'RB'),
    ('Miles Sanders', '1997-05-01', 'RB'),
    ('Xavier Legette', '2001-01-29', 'WR'),
    ('Diontae Johnson', '1996-07-05', 'WR'),
	('Johnathan Mingo', '2001-04-20', 'WR'),
    ('Adam Thielan', '1990-08-22', 'WR'),
    ('Tommy Tremble', '2000-07-02', 'TE'),
    ('Ian Thomas', '1996-06-06', 'TE');

#Chicago Bears Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('Caleb Willaims', '2001-11-18', 'QB'),
    ('DAndre Swift', '1999-01-14', 'RB'),
    ('Roschon Johnson', '2001-01-31', 'RB'),
    ('Khalil Herbert', '1998-04-21', 'RB'),
    ('DJ Moore', '1997-04-14', 'WR'),
	('Rome Odunze', '2002-06-03', 'WR'),
    ('Keenan Allen', '1992-04-27', 'WR'),
    ('Cole Kmet', '1999-03-10', 'TE'),
    ('Gerald Everett', '1994-06-25', 'TE');
    
#Cincinnati Bengals Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('Joe Burrow', '1996-12-10', 'QB'),
    ('Chase Brown', '2000-03-21', 'RB'),
    ('Zach Moss', '1997-12-15', 'RB'),
    ('JaMarr Chase', '2000-03-01', 'WR'),
    ('Tee Higgins', '1999-01-18', 'WR'),
	('Andrei Iosivas', '1999-10-15', 'WR'),
    ('Trenton Irwin', '1995-12-10', 'WR'),
    ('Mike Gesicki', '1995-10-03', 'TE'),
    ('Erick All', '2000-09-13', 'TE');
    
    #Cleveland Browns Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('Deshaun Watson', '1995-09-14', 'QB'),
    ('Jameis Winston', '1994-01-06', 'QB'),
    ('Jerome Ford', '1996-04-24', 'RB'),
    ('Donta Foreman', '1997-12-15', 'RB'),
    ('Cedric Tillman', '2000-04-19', 'WR'),
    ('Elijah Moore', '2000-03-27', 'WR'),
	('Jerry Judey', '1999-04-24', 'WR'),
    ('David Bell', '2000-12-14', 'WR'),
    ('David Njoku', '1996-07-10', 'TE'),
    ('Jordan Akins', '1992-04-19', 'TE');
    
    #Dallas Cowboys Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('Dak Prescott', '1993-07-29', 'QB'),
    ('Rico Dowdle', '1998-06-14', 'RB'),
    ('Ezekiel Elliott', '1995-07-22', 'RB'),
    ('CeeDee Lamb', '1999-04-08', 'WR'),
    ('KaVontae Turpin', '1996-08-02', 'WR'),
	('Brandin Cooks', '1993-09-25', 'WR'),
    ('Jalen Tolbert', '1999-02-27', 'WR'),
    ('Jake Ferguson', '1999-01-18', 'TE'),
    ('Luke Schoonmaker', '1998-09-28', 'TE');
    
        #Denver Broncos Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('Bo Nix', '2000-02-25', 'QB'),
    ('Javonte Williams', '2000-04-25', 'RB'),
    ('Jaleel McLaughlin', '2000-09-11', 'RB'),
    ('Troy Franklin', '2003-02-06', 'WR'),
    ('Marvin Mims', '2002-03-19', 'WR'),
	('Courtland Sutton', '1995-10-10', 'WR'),
    ('LilJordan Humphrey', '1998-04-19', 'WR'),
    ('Lucas Krull', '1998-07-11', 'TE'),
    ('Adam Trautman', '1997-02-05', 'TE');
    
            #Detroit Lions Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('Jared Goff', '1994-10-14', 'QB'),
    ('David Montgomery', '1997-07-07', 'RB'),
    ('Jahmyr Gibbs', '2002-03-20', 'RB'),
    ('Jameson Willaims', '2001-03-26', 'WR'),
    ('Kalif Raymond', '1994-08-08', 'WR'),
	('Amon Ra St. Brown', '1999-10-24', 'WR'),
    ('Tim Patrick', '1993-11-23', 'WR'),
    ('Sam LaPorta', '2001-01-12', 'TE'),
    ('Brock Wright', '1998-11-27', 'TE');
    
                #Green Bay Packers Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('Jordan Love', '1998-11-02', 'QB'),
    ('Malik Willis', '1999-05-25', 'QB'),
    ('Josh Jacobs', '1998-02-11', 'RB'),
    ('Emanuel Wilson', '1999-05-08', 'RB'),
    ('Jayden Reed', '2000-04-28', 'WR'),
    ('Christian Watson', '1999-05-12', 'WR'),
	('Romeo Doubs', '2000-04-13', 'WR'),
    ('Dontayvion Wicks', '2001-06-16', 'WR'),
    ('Bo Melton', '1999-05-18', 'WR'),
    ('Tucker Kraft', '2000-11-03', 'TE'),
    ('Luke Musgrave', '2000-09-02', 'TE');
    
                    #Houston Texans Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('CJ Stroud', '2001-10-03', 'QB'),
    ('Joe Mixon', '1996-07-24', 'RB'),
    ('Cam Akers', '1999-06-22', 'RB'),
    ('Tank Dell', '1999-10-29', 'WR'),
    ('Stefon Diggs', '1999-05-12', 'WR'),
	('Steven Sims', '1993-11-29', 'WR'),
    ('Nico Collins', '1999-03-19', 'WR'),
    ('Dalton Schultz', '1996-07-11', 'TE'),
    ('Cade Stover', '2000-06-12', 'TE');
    
                        #Indianapolis Colts Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('Anthony Richardson', '2002-05-22', 'QB'),
    ('Joe Flacco', '1985-01-16', 'QB'),
    ('Jonathan Taylor', '1999-01-19', 'RB'),
	('Trey Sermon', '1999-01-30', 'RB'),
    ('Adonai Mitchel', '2002-10-08', 'WR'),
    ('Josh Downs', '2001-08-12', 'WR'),
	('Michael Pittman Jr', '1997-10-05', 'WR'),
    ('Alex Pierce', '2000-05-02', 'WR'),
    ('Mo Alie Cox', '1993-09-19', 'TE'),
    ('Andrew Ogletree', '1998-07-28', 'TE');


	#Jacksonville Jaguars Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('Trevor Lawrence', '1999-10-06', 'QB'),
    ('Tank Bigsby', '2001-08-30', 'RB'),
	('Travis Etienne', '1999-01-26', 'RB'),
    ('Brian Thomas', '2002-10-08', 'WR'),
    ('Chirstian Kirk', '1996-11-18', 'WR'),
	('Gabriel Davis', '1999-04-01', 'WR'),
    ('Parker Washington', '2002-03-21', 'WR'),
    ('Even Engram', '1994-09-02', 'TE'),
    ('Brenton Strange', '2000-12-27', 'TE');
    
    #Kansas City Cheifs Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('Patrick Mahomes', '1995-09-17', 'QB'),
    ('Kareem Hunt', '1995-08-06', 'RB'),
	('Carson Steele', '2002-10-21', 'RB'),
    ('Xavier Worthy', '2003-04-27', 'WR'),
    ('Mecole Hardman', '1998-03-12', 'WR'),
	('Justin Watson', '1995-04-04', 'WR'),
    ('JuJu Smith Schuster', '1996-11-22', 'WR'),
    ('DeAndre Hopkins', '1992-06-06', 'WR'),
    ('Travis Kelce', '1989-10-05', 'TE'),
    ('Noah Gray', '1999-04-30', 'TE');
    
     #Las Vegas Raiders Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('Gardner Minshew', '1996-05-16', 'QB'),
	('Aidan O Connell', '1998--09-01', 'QB'),
    ('Alexander Mattison', '1998-06-19', 'RB'),
	('Zamir White', '1999-09-18', 'RB'),
    ('Tre Tucker', '2001-03-08', 'WR'),
    ('DJ Turner', '1997-01-18', 'WR'),
	('Jakobi Meyers', '1996-11-09', 'WR'),
    ('Tyreik McAllister', '1998-04-07', 'WR'),
    ('Brock Bowers', '2002-12-13', 'TE'),
    ('Harrison Bryant', '1998-04-23', 'TE');
    
         #Los Angeles Chargers Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('Justin Herbert', '1998-03-10', 'QB'),
    ('JK Dobbins', '1998-12-17', 'RB'),
	('Gus Edwards', '1998-04-13', 'RB'),
    ('Ladd McConkey', '2001-11-11', 'WR'),
    ('Josh Palmer', '1999-09-22', 'WR'),
	('Simi Fehoko', '1997-11-05', 'WR'),
    ('Quentin Johnston', '2001-09-06', 'WR'),
    ('Will Dissly', '1996-07-08', 'TE'),
    ('Hayden Hurst', '1993-08-24', 'TE');
    
		# Los Angeles Rams Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('Matthew Stafford', '1988-02-07', 'QB'),
    ('Kyren Willaims', '2000-08-26', 'RB'),
	('Blake Corum', '2000-11-25', 'RB'),
    ('Puka Nacua', '2001-05-29', 'WR'),
    ('Cooper Kupp', '1993-06-15', 'WR'),
	('Tutu Atwell', '1999-10-07', 'WR'),
    ('Jordan Whittington', '2000-10-01', 'WR'),
    ('Colby Parkinson', '1999-01-08', 'TE'),
    ('Hunter Long', '1998-08-19', 'TE');

	# Miami Dolphins Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('Tua Tagovailoa', '1998-03-02', 'QB'),
    ('DeVon Achane', '2001-10-13', 'RB'),
	('Raheem Mostert', '1992-04-09', 'RB'),
    ('Jaylen Wright', '2003-04-01', 'RB'),
    ('Tyreek Hill', '1994-03-01', 'WR'),
    ('Jaylen Waddle', '1998-11-25', 'WR'),
	('Malik Washington', '2001-01-04', 'WR'),
    ('Jonnu Smith', '1995-08-22', 'TE'),
    ('Julian Hill', '2000-07-09', 'TE');
    
    # Minnesota Vikings Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('Sam Darnold', '1997-06-05', 'QB'),
    ('Aaron Jones', '1994-12-02', 'RB'),
	('Ty Chandler', '1998-05-12', 'RB'),
    ('Jalen Nailor', '1999-03-02', 'WR'),
    ('Justin Jefferson', '1999-06-19', 'WR'),
	('Jordan Addison', '2002-01-27', 'WR'),
    ('Johnny Mundt', '1994-11-23', 'TE'),
    ('Josh Oliver', '1997-03-21', 'TE');
    
     # New England Patriots Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('Jacoby Brissett', '1992-12-11', 'QB'),
    ('Drake Maye', '2002-08-30', 'QB'),
    ('Rhamondre Stevenson', '1998-02-23', 'RB'),
	('Antonio Gibson', '1998-06-23', 'RB'),
    ('Demario Douglas', '2000-12-08', 'WR'),
    ('JaLynn Polk', '2002-04-11', 'WR'),
	('Kayshon Boutte', '2002-05-07', 'WR'),
    ('Hunter Henry', '1994-12-07', 'TE'),
    ('Austin Hooper', '1994-10-29', 'TE');
    
    # New Orleans Saints Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('Derek Carr', '1991-03-28', 'QB'),
    ('Spencer Rattler', '2000-09-28', 'QB'),
    ('Alvin Kamara', '1995-07-25', 'RB'),
	('Jamaal Williams', '1995-04-03', 'RB'),
    ('Rashid Shaheed', '1998-08-31', 'WR'),
    ('Chris Olave', '2000-07-27', 'WR'),
	('Mason Tipton', '2000-09-27', 'WR'),
    ('Taysom Hill', '1990-08-23', 'TE'),
    ('Juwan Johnson', '1996-09-13', 'TE');
    
    # New York Giants Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('Daniel Jones', '1997-05-27', 'QB'),
    ('Tyrone Tracy', '1999-11-23', 'RB'),
	('Devin Singletary', '1997-09-03', 'RB'),
    ('Malik Nabers', '2003-07-28', 'WR'),
    ('WanDale Robinson', '2001-01-05', 'WR'),
	('Darius Slayton', '1997-01-12', 'WR'),
    ('Theo Johnson', '2001-02-26', 'TE'),
    ('Daniel Bellinger', '2000-09-22', 'TE');
    
    # New York Jets Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('Aaron Rodgers', '1983-12-02', 'QB'),
    ('Breece Hall', '2001-05-31', 'RB'),
	('Braelon Allen', '2004-01-20', 'RB'),
    ('Garrett Wilson', '2000-07-22', 'WR'),
    ('Allen Lazard', '1995-12-11', 'WR'),
	('Devante Adams', '1992-12-24', 'WR'),
    ('Mike Willaims', '1994-10-04', 'WR'),
    ('Tyler Conklin', '1995-07-30', 'TE'),
    ('Jeremy Ruckert', '2000-08-11', 'TE');
    
    # Philadelphia Eagles Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('Jalen Hurts', '1998-08-07', 'QB'),
    ('Saquan Barkley', '1997-02-09', 'RB'),
	('Kenneth Gainwell', '1999-03-14', 'RB'),
    ('Jahan Dotson', '2000-03-22', 'WR'),
    ('DeVonta Smith', '1998-11-14', 'WR'),
	('AJ Brown', '1997-06-30', 'WR'),
    ('Britain Covey', '1997-03-18', 'WR'),
    ('Dallas Goedert', '1995-01-03', 'TE'),
    ('Grant Calcaterra', '1998-12-04', 'TE');
    
     # Pittsburgh Steelers Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('Justin Fields', '1999-03-05', 'QB'),
    ('Russell Wilson', '1988-11-29', 'QB'),
    ('Najee Harris', '1998-03-09', 'RB'),
	('Jaylen Warren', '1998-11-01', 'RB'),
    ('George Pickens', '2001-03-04', 'WR'),
    ('Calvin Austin', '1999-03-24', 'WR'),
	('Van Jefferson', '1996-07-26', 'WR'),
    ('Pat Freiermuth', '1998-10-25', 'TE'),
    ('Darnell Washington', '2001-08-17', 'TE');
    
    # San Francisco 49ers Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('Brock Purdy', '1999-12-27', 'QB'),
    ('Jordan Mason', '1999-05-24', 'RB'),
	('Isacc Guerendo', '2000-06-28', 'RB'),
    ('Deebo Samuel', '1996-01-15', 'WR'),
    ('Ricky Pearsall', '2000-09-09', 'WR'),
	('Brandon Aiyuk', '1998-03-17', 'WR'),
    ('Jauan Jennings', '1997-07-10', 'WR'),
    ('George Kittle', '1993-10-09', 'TE'),
    ('Eric Saubert', '1994-05-01', 'TE');
    
    # Seattle Seahawks Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('Geno Smith', '1990-10-10', 'QB'),
    ('Kenneth Walker', '2000-10-20', 'RB'),
	('Zach Charbonnet', '2001-01-08', 'RB'),
    ('Jaxon Smith Njigba', '2002-02-14', 'WR'),
    ('DK Metcalf', '1997-12-14', 'WR'),
	('Tyler Lockett', '1992-09-28', 'WR'),
    ('Jake Bobo', '1998-08-04', 'WR'),
    ('Noah Fant', '1997-11-20', 'TE'),
    ('AJ Barner', '2002-05-03', 'TE');
    
    # Tampa Bay Buccaneers Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('Baker Mayfield', '1995-04-14', 'QB'),
    ('Bucky Irving', '2002-08-19', 'RB'),
	('Rachaad White', '1999-01-22', 'RB'),
    ('Sterling Shapard', '1993-02-10', 'WR'),
    ('Chris Godwin', '1996-02-27', 'WR'),
	('Mike Evans', '1993-08-21', 'WR'),
    ('Trey Palmer', '2001-04-02', 'WR'),
    ('Jalen McMillan', '2001-12-07', 'WR'),
    ('Cade Otton', '1999-04-15', 'TE');
    
    # Tennessee Titans Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('Will Levis', '1999-06-27', 'QB'),
    ('Mason Rudolph', '1995-07-17', 'QB'),
    ('Tony Pollard', '1997-04-30', 'RB'),
	('Tyjae Spears', '2001-06-15', 'RB'),
    ('Calvin Ridley', '1994-12-20', 'WR'),
    ('Tyler Boyd', '1994-11-15', 'WR'),
	('Treylon Burks', '2000-03-23', 'WR'),
    ('Nick Westbrook Ikhine', '1997-03-21', 'WR'),
    ('Chigoziem Okonkwo', '1999-09-08', 'WR'),
    ('Josh Whyle', '1999-09-08', 'TE');
    
        # Washinton Commanders Players
INSERT INTO Player (PlayerName, Birthdate, Position)
	VALUES 
    ('Jayden Daniels', '2000-12-18', 'QB'),
    ('Marcus Mariota', '1993-10-30', 'QB'),
    ('Brain Robinson Jr', '1999-03-22', 'RB'),
	('Austin Ekeler', '1995-05-17', 'RB'),
    ('Terry McLaurin', '1995-09-15', 'WR'),
    ('Olamide Zaccheaus', '1997-07-23', 'WR'),
	('Noah Brown', '2000-03-23', 'WR'),
    ('Luke McCaffery', '2001-04-02', 'WR'),
    ('Zach Ertz', '1990-11-10', 'WR'),
    ('John Bates', '1997-11--06', 'TE');















 
    