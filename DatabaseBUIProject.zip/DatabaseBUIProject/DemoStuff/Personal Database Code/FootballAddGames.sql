insert into Game(GameID, Week, Location) 
values 
(1,1,"Chicago, Illinois"), #Chicago Bears Games
(2,2,"Houston, Texas"),
(3,3,"Indianapolis, Indiana"),
(4,4,"Chicago, Illinois"),
(5,5,"Chicago, Illinois"),
(6,6,"Chicago, Illinois"),
(7,8,"Landover, Maryland"),
(8,9,"Glendale, Arizona"),
(9,10,"Chicago, Illinois"),
(10,1,"Detroit, Michigan"), #Detroit Lions Games
(11,2,"Detroit, Michigan"),
(12,3,"Glendale, Arizona"),
(13,4,"Detroit, Michigan"),
(14,6,"Dallas, Texas"),
(15,7,"Minneapolis, Minnesota"),
(16,8,"Detroit, Michigan"),
(17,9,"Green Bay, Wisconsin"),
(18,10,"Houston, Texas"),
(19,1,"Rio De Jinero, Brazil"), #Green Bay Packers Games
(20,2,"Green Bay, Wiscosin"),
(21,3,"Nasheville, Tennessee"),
(22,4,"Green Bay, Wiscosin"), 
(23,5,"Los Angeles, California"),
(24,6,"Green Bay, Wiscosin"),
(25,7,"Green Bay, Wiscosin"),
(26,8,"Jacksonville, Florida"),
##(27,9,"Green Bay, Wiscosin"),
(28,1,"East Rutherford, New Jersey"), #Minnesota Vikings Games
(29,2,"Minneapolis, Minnesota"),
(30,3,"Minneapolis, Minnesota"),
##(31,4,"Green Bay, Wisconsin"),
(32,5,"Minneapolis, Minnesota"),
##(33,7,"Minneapolis, Minnesota"),
(34,8,"Los Angeles, California"),
(35,9,"Minneapolis, Minnesota"),
(36,10,"Jacksonville, Florida");


